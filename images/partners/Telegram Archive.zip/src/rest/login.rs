use std::str::FromStr;

use axum_sessions::{
    async_session::MemoryStore,
    extractors::{ReadableSession, WritableSession},
    SessionLayer,
};  
use axum::{
    routing::{get, post},
    extract::State,
    Json, Router,
    http::{Request, StatusCode},
    response::{IntoResponse, Response},
    middleware::{self, Next},
    extract::Extension,
};
use http::HeaderValue;
use serde::Deserialize;

#[derive(Deserialize)]
pub struct LoginData {
    username: String,
    password:   String,
}

pub async fn me(mut session: ReadableSession)->impl IntoResponse{
    format!("user_id={}",session.get("user_id").unwrap_or(-1))
}
pub async fn login(
        mut session: WritableSession,
        Json(payload): Json<LoginData>,
    )->impl IntoResponse{

    let mut user_id= session.get("user_id").unwrap_or(-1);
    session.insert("user_id", 1);
    format!("Count is: {}", user_id)

}
pub async fn logout(mut session: WritableSession)->impl IntoResponse{
    session.destroy();
}

pub async fn auth<B>(mut session: WritableSession,mut req: Request<B>, next: Next<B>) -> Result<Response, StatusCode> {
    req.headers_mut().append("user_id", HeaderValue::from_str(&format!("{}",1)).unwrap());
    Ok(next.run(req).await)
    /*let user_id=session.get("user_id").unwrap_or(-1);
    if user_id==-1{
        Err(StatusCode::UNAUTHORIZED)
    }else{
        req.headers_mut().append("user_id", HeaderValue::from_str(&format!("{}",user_id)).unwrap());
        Ok(next.run(req).await)
    }*/
}