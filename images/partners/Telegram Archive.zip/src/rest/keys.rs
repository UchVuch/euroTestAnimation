use std::sync::Arc;

use serde::{Serialize,Deserialize};
use axum::{
    extract::State,
    extract::Query,
    Json,
    response::{IntoResponse},
};
use axum_sessions::{
    extractors::{ReadableSession},
};
use axum::extract::Path;
use tokio::sync::Mutex;

use crate::{database::AppState, rest::result_to_response};

#[derive(Serialize,serde::Deserialize)]
pub struct KeyGenerationInputData {
    nonce:String,
    regcount:i8,
    reason:String,
    company:String,
    options:String,
}
pub fn saveToStats(inputData:&KeyGenerationInputData){

}
fn getMd5(data:&str)->String{
    format!("{:x}",md5::compute(data))
}
fn getHex(data:&str)->String{
    hex::encode(data)
}
pub async fn generateKey(
    Query(input_data): Query<KeyGenerationInputData>,
    State(state): State<Arc<Mutex<AppState>>>,)->impl IntoResponse{
    let md5secret=getMd5("VSB-Terminal");
    //saveToStats(&inputData);//TODO
    #[derive(serde::Serialize)]
    struct Key{
        first:String,
        second:String,
    }
    let mut keysArr:Vec<Key>=Vec::new();
    for nonce in input_data.nonce.split(","){
        keysArr.push(Key{
            first:getMd5(format!("{}{}",nonce,md5secret).as_str()),
            second:getHex(format!("{}{}{}{}",nonce,input_data.options.as_str(),"|",input_data.regcount).as_str()),
        });
    }
    result_to_response(Ok(keysArr))
}