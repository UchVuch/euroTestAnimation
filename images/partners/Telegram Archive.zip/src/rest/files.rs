use std::{sync::Arc, io::Write};
use crate::database::files::{Dir,File};
use http::{StatusCode, HeaderValue};
use serde::{Serialize,Deserialize};
use axum::{
    extract::State,
    extract::Multipart,
    extract::Query,
    Json,
    response::{IntoResponse, Response},
};
use axum_sessions::{
    extractors::{ReadableSession},
};
use axum::extract::Path;
use tokio::sync::Mutex;
use anyhow::anyhow;

use crate::{database::AppState, rest::result_to_response};


pub async fn getDir(data: State<Arc<Mutex<AppState>>>,Path(idv):Path<i32>) ->impl IntoResponse{
    let mut a=data.lock().await;
    let dir=a.db.get_dir(&idv).await;
    if let Err(err)=dir{
        return result_to_response(Err(anyhow!(err)));
    }
    #[derive(Serialize)]
    struct DirHeader{
        name: String,
        id:i32,
    }
    #[derive(Serialize)]
    struct FileHeader{
        id: i32,
        name: String,
        caption: String,
    }
    #[derive(Serialize)]
    struct Response{
        dirs: Vec<DirHeader>,
        files: Vec<FileHeader>,
    }
    let mut response=Response{
        dirs: Vec::new(),
        files: Vec::new(),
    };
    let entries=std::fs::read_dir(dir.unwrap().path);
    if let Err(err)=entries{
        return result_to_response(Err(anyhow!(err)));
    }
    for entryr in entries.unwrap(){
        if entryr.is_err(){
            continue;
        }

        let entry=entryr.unwrap().path();
        let pathstr=entry.to_str();
        if pathstr.is_none(){
            continue;
        }

        if entry.is_dir() {
            let rdir=a.db.get_dir_by_path(&String::from(pathstr.unwrap())).await;
            if rdir.is_err(){
                continue;
            }
            let dir=rdir.unwrap();
            let name=dir.path.split('/').last();
            if name.is_none(){
                continue;
            }
            response.dirs.push(DirHeader{id:dir.id,name:String::from(name.unwrap())});
        } else {
            let rfile=a.db.get_file_by_path(&String::from(pathstr.unwrap())).await;
            if rfile.is_err(){
                continue;
            }
            let file=rfile.unwrap();
            let name=file.path.split('/').last();
            if name.is_none(){
                continue;
            }
            response.files.push(FileHeader{id:file.id,name:String::from(name.unwrap()),caption:file.caption});
        }
    }
    (result_to_response(Ok(response)))
}

fn getPathToObjectFromObjectPath(objectPath: & String)-> String{

    let lastsplitterindex=objectPath.rfind('/');
    objectPath.chars().take(lastsplitterindex.unwrap()).collect()
}

pub async fn editDir(data: State<Arc<Mutex<AppState>>>,Path(dir_id):Path<i32>,Json(dir):Json<ApiEditDir>) ->impl IntoResponse{
    let mut a=data.lock().await;
    let cur_dir_res=a.db.get_dir(&dir_id).await;
    if cur_dir_res.is_err(){
        return result_to_response(cur_dir_res.map(|x|{()}));
    }
    let cur_path=cur_dir_res.unwrap().path;
    let path_to_folder=getPathToObjectFromObjectPath(&cur_path);
    let new_path=format!("{}/{}",path_to_folder,dir.name);
    let edit_result=a.db.edit_dir(dir_id,Dir{
        id:0,
        path:new_path.clone(),
    }).await;

    if edit_result.is_err(){
        result_to_response(edit_result)
    }else{
        let res=std::fs::rename(cur_path.as_str(),new_path.as_str());
        result_to_response(res.map_err(|err|{anyhow!(err)}))
    }

}

#[derive(Serialize,Deserialize)]
pub struct ApiNewDir{
    name:String,
    dir_id:i32,
}

#[derive(Serialize,Deserialize)]
pub struct ApiEditDir{
    name:String,
}

#[derive(Serialize,Deserialize)]
pub struct ApiEditFile{
    name:String,
    caption:String,
}
#[derive(Serialize,Deserialize)]
pub struct ApiNewFile{
    name:String,
    caption:String,
    dir_id:i32,
}

pub async fn addDir(data: State<Arc<Mutex<AppState>>>,Json(dir):Json<ApiNewDir>) ->impl IntoResponse{
    let mut a=data.lock().await;
    let cur_dir_res=a.db.get_dir(&dir.dir_id).await;
    if let Err(err)=cur_dir_res{
        return result_to_response(Err(anyhow!(err.to_string())));
    }
    let cur_dir=cur_dir_res.unwrap();
    let new_dir= Dir{
        id:0,
        path:format!("{}/{}",cur_dir.path,dir.name),
    };
    let create_dir_res=std::fs::create_dir(new_dir.path.clone());
    if let Err(err)=create_dir_res{
        return result_to_response(Err(anyhow!(err)));
    }
    let result= a.db.add_dir(new_dir).await;

    return result_to_response(result);
}


pub async fn deleteDir(data: State<Arc<Mutex<AppState>>>,dir_id:Path<i32>) ->impl IntoResponse{
    let mut a=data.lock().await;

    let rdir=a.db.get_dir(&dir_id).await;
    if let Err(err)=rdir{
        return result_to_response(Err(anyhow!(err)));
    }
    let dir=rdir.unwrap();
    let entries = std::fs::read_dir(dir.path.clone());
    if entries.is_err()||(entries.is_ok()&&entries.unwrap().count()>0){
        return result_to_response(Err(anyhow!("Unknown err")));
    }

    let rmres=std::fs::remove_dir(dir.path);
    if let Err(err)=rmres{
        return result_to_response(Err(anyhow!(err)));
    }
    let result= a.db.delete_dir(&dir_id).await;
    result_to_response(result)
}

pub async fn getFile(data: State<Arc<Mutex<AppState>>>,file_id:Path<i32>)-> impl IntoResponse{
    let mut a=data.lock().await;
    let file=a.db.get_file(&file_id).await;
    let mut res=Response::new(String::new());
    match file{
        Ok(file) =>{
            if let st =std::fs::read_to_string(file.path.clone()).unwrap(){
                let name=file.path.split('/').last();
                if name.is_none(){
                    *res.status_mut()=StatusCode::INTERNAL_SERVER_ERROR;
                    return res;
                }
                res.headers_mut().append("content-disposition", HeaderValue::from_str(format!("attachment; filename={}",name.unwrap()).as_str()).unwrap());
                res.headers_mut().append("Content-Type", HeaderValue::from_str("application/octet-stream").unwrap());

                return res;
            }else{
                *res.status_mut()=StatusCode::INTERNAL_SERVER_ERROR;
                return res;
            }
        }
        Err(err) =>{
            *res.status_mut()=StatusCode::INTERNAL_SERVER_ERROR;
            return res;
        }
    }
}

pub async fn addFile(data: State<Arc<Mutex<AppState>>>,mut payload: Multipart)->impl IntoResponse {
    let mut form=ApiNewFile{
        caption: String::new(),
        name: String::new(),
        dir_id:0,
    };

    let mut temp_file_path=String::new();

    while let Ok(Some(mut field)) = payload.next_field().await {
        // A multipart/form-data stream has to contain `content_disposition`
        let name = field.name().unwrap_or("");
        if name=="config"{
            while let Some(chunk) = field.chunk().await.unwrap() {
                if let Ok(s) = std::str::from_utf8(&chunk) {
                    let data_string = s.to_string();
                    form=serde_json::from_str(&data_string).unwrap_or(form);
                };
            }
        }else if name=="files"{
            let filename = field.file_name()
                .unwrap_or("error.txt");


            let filepathstring = format!("./cache/{filename}");
            temp_file_path=filepathstring.clone();

            let mut f = std::fs::File::create(filepathstring).unwrap();

            while let Ok(Some(chunk)) = field.chunk().await {
                f.write_all(&chunk);
            }
        }


    }
    let mut api=data.lock().await;
    let dir=api.db.get_dir(&form.dir_id).await;
    if dir.is_err(){
        return result_to_response(Err(anyhow!("Error")));
    }
    let filepath=String::from(format!("{}/{}",dir.unwrap().path,form.name));
    api.db.add_file(File{ id:0,path: filepath.clone(), caption: String::new() }).await;
    std::fs::copy(temp_file_path.clone(),filepath);
    std::fs::remove_file(temp_file_path);
    return result_to_response(Ok(()));
}

pub async fn deleteFile(data: State<Arc<Mutex<AppState>>>,id:Path<i32>)->impl IntoResponse{

    let mut api=data.lock().await;
    let file=api.db.get_file(&id).await;
    if file.is_err(){
        return result_to_response(Err(anyhow!("Error")));
    }
    let remove_result=std::fs::remove_file(file.unwrap().path);
    if remove_result.is_err(){
        return result_to_response(Err(anyhow!("Error")));
    }
    let res=api.db.delete_file(&id).await;
    return result_to_response(res);
}

pub async fn editFile(data: State<Arc<Mutex<AppState>>>,id: Path<i32>,Json(file):Json<ApiEditFile>)->impl IntoResponse{
    let mut a=data.lock().await;

    let cur_dir_res=a.db.get_file(&id).await;
    if let Err(err)=cur_dir_res{
        return result_to_response(Err(anyhow!(err.to_string())));
    }

    let cur_path=cur_dir_res.unwrap().path;
    let path_to_folder=getPathToObjectFromObjectPath(&cur_path);
    let new_path=format!("{}/{}",path_to_folder,file.name);
    let edit_result=a.db.edit_file(&id,File{
        id:0,
        path:new_path.clone(),
        caption:file.caption,
    }).await;
    if let Err(err)=edit_result{
        return result_to_response(Err(anyhow!(err.to_string())));
    }else{
        std::fs::rename(cur_path,new_path);
        return result_to_response(Ok(()));
    }
}