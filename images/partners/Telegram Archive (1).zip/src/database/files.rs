use serde::{Deserialize,Serialize};
use sqlx::{FromRow,postgres::PgRow,Row};
use anyhow::Result;
use sea_query::{Query, PostgresQueryBuilder,Expr, query};
use crate::database::tables::{Dirs,Files};

#[derive(Debug,Serialize,Deserialize,Clone,FromRow)]
pub struct File {
    pub id: i32,
    pub path: String,
    pub caption: String,
}

#[derive(Debug,Serialize,Deserialize,Clone,FromRow)]
pub struct Dir {
    pub id: i32,
    pub path: String,
}

impl crate::database::Database{
    pub async fn get_dir_by_path(&mut self, path:&String) -> Result<Dir>{
        let query=Query::select().from(Dirs::Table)
        .columns([Dirs::Id])
        .and_where(Expr::col(Dirs::Path).eq(path))
        .to_string(PostgresQueryBuilder);

        let res=sqlx::query(&query).fetch_one(&self.db).await?;
        Ok(Dir{id:res.get(0),path:path.clone()})
    }
    pub async fn get_file_by_path(&mut self,path:&String) -> Result<File>{
        let query=Query::select().from(Files::Table)
        .columns([Files::Caption,Files::Id,Files::Path])
        .and_where(Expr::col(Files::Path).eq(path))
        .to_string(PostgresQueryBuilder);

        let res=sqlx::query(&query).fetch_one(&self.db).await?;

        Ok(File::from_row(&res)?)

    }
    pub async fn edit_dir(&mut self, id: i32, dir: Dir) -> Result<()> {
        let query=Query::update().table(Dirs::Table)
        .and_where(Expr::col(Dirs::Id).eq(id))
        .values([(Dirs::Path,dir.path.into())])
        .to_string(PostgresQueryBuilder);
        
        sqlx::query(&query).execute(&self.db).await?;
        Ok(())
    }
    pub async fn get_dir(&mut self, idv: &i32) -> Result<Dir> {
        if *idv==0{
            return Ok(Dir{ id: 0, path: "./files".to_string() });
        }
        let query=Query::select().from(Dirs::Table)
        .columns([Dirs::Path,Dirs::Id])
        .and_where(Expr::col(Dirs::Id).eq(*idv))
        .to_string(PostgresQueryBuilder);

        let row=sqlx::query(&query).fetch_one(&self.db).await?;
        Ok(Dir::from_row(&row)?)
    }
    pub async fn add_dir(& mut self, new_dir : Dir)->Result<i32>{
        let query=Query::insert().into_table(Dirs::Table)
        .returning_col(Dirs::Id)
        .columns([Dirs::Path])
        .values([new_dir.path.into()])
        .unwrap().to_string(PostgresQueryBuilder);

        Ok(sqlx::query(&query).fetch_one(&self.db).await?.get(0))
    }
    pub async fn delete_dir(&mut self,idv:&i32)->Result<()>{
        let query=Query::delete().from_table(Dirs::Table)
        .and_where(Expr::col(Dirs::Id).eq(*idv))
        .to_string(PostgresQueryBuilder);

       sqlx::query(&query).execute(&self.db).await?;
       Ok(())
    }
    pub async fn add_file(&mut self, file:File) -> Result<i32> {
        let query=Query::insert().into_table(Files::Table)
        .columns([Files::Caption,Files::Path])
        .values([file.caption.into(),file.path.into()])
        .unwrap()
        .returning_col(Files::Id)
        .to_string(PostgresQueryBuilder);

        Ok(sqlx::query(&query).fetch_one(&self.db).await?.get(0))
    }
    pub async fn get_file(& mut self,idv:&i32)->Result<File>{
        let query=Query::select().from(Files::Table)
        .and_where(Expr::col(Files::Id).eq(*idv))
        .columns([Files::Id,Files::Caption,Files::Path])
        .to_string(PostgresQueryBuilder);

        let row=sqlx::query(&query).fetch_one(&self.db).await?;
        Ok(File::from_row(&row)?)
    }
    pub async fn edit_file(&mut self,idv:&i32,file:File)->Result<()>{
        let query=Query::update().table(Files::Table)
        .values([(Files::Caption,file.caption.into()),(Files::Path,file.path.into())])
        .and_where(Expr::col(Files::Id).eq(*idv))
        .to_string(PostgresQueryBuilder);

        sqlx::query(&query).execute(&self.db).await?;
        Ok(())
    }
    pub async fn delete_file(&mut self,idv:&i32)->Result<()>{
        let query=Query::delete().from_table(Files::Table)
        .and_where(Expr::col(Files::Id).eq(*idv))
        .to_string(PostgresQueryBuilder);

        sqlx::query(&query).execute(&self.db).await?;
        Ok(())
    }
}