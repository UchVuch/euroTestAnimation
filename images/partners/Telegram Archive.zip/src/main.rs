use std::sync::Arc;

use axum::{
    routing::{get, post,put,delete},
    extract::State,
    Json, Router,
    http::{Request, StatusCode},
    response::{IntoResponse, Response},
    middleware::{self, Next},
    extract::Extension,
};
use axum_sessions::{
    async_session::MemoryStore,
    extractors::{ReadableSession, WritableSession},
    SessionLayer,
};  
use serde::{Deserialize, Serialize};
use anyhow::{Context, Result};
use tokio::sync::Mutex;
use sqlx::{postgres::PgPoolOptions};

mod rest;
mod database;



#[tokio::main]
async fn main() -> Result<()>{

    tracing_subscriber::fmt()
    .with_max_level(tracing::Level::INFO)
    .with_target(false)
    .init();

    std::panic::set_hook(Box::new(|panic_info| {
        tracing::error!("CRITICAL ERROR :{:?}",panic_info);
    }));

    let store = MemoryStore::new();
    let mut secret = [0u8; 128];
    getrandom::getrandom(&mut secret)?;
    let session_layer = SessionLayer::new(store, &secret).with_secure(false);

    let pool = PgPoolOptions::new()
    .max_connections(5)
    .connect("postgres://postgres@localhost:5432/vsb_tender").await?;

    tracing::info!("БД подключена");
    //let res=qwx_migrations::apply_migrations(& pool,"./src/migrations").await;
    sqlx::migrate!("./src/migrations")
    .run(&pool)
    .await?;
    tracing::info!("Миграции применены");
    


    let tender_routes = Router::new()
        .route("/table_settings",post(rest::tenders::save_table_settings))
        .route("/table_settings",get(rest::tenders::get_table_settings))
        .route("/", get(rest::tenders::get_tenders))
        .route("/",post(rest::tenders::add_tender))
        .route("/:id",get(rest::tenders::get_tender))
        .route("/:id",delete(rest::tenders::delete_tender))
        .route("/:id",put(rest::tenders::update_tender));

    let user_routes = Router::new()
        .route("/",get(rest::users::usersList))
        .route("/:id",delete(rest::users::deleteUser))
        .route("/:id",put(rest::users::editUser))
        .route("/",post(rest::users::addUser))
        .route("/:id",get(rest::users::getUser));

    let file_routes=Router::new()
        .route("/",post(rest::files::addFile))
        .route("/:id",get(rest::files::getFile))
        .route("/:id", put(rest::files::editFile))
        .route("/:id", delete(rest::files::deleteFile));

    let dir_routes=Router::new()
        .route("/:id", get(rest::files::getDir))
        .route("/:id",delete(rest::files::deleteDir))
        .route("/:id", put(rest::files::editDir))
        .route("/",post(rest::files::addDir));


     let api_routes = Router::new()
        .nest("/tenders",tender_routes)
        .nest("/users",user_routes)
        .nest("/files",file_routes)
        .nest("/dirs",dir_routes)
        .route("/roles",get(rest::users::rolesList))
        .route("/key",get(rest::keys::generateKey))
        .route_layer(axum::middleware::from_fn(rest::login::auth));
 

    let serv=tower_http::services::ServeDir::new("./frontend/dist/assets");
    
    let app = Router::new()
        .nest_service("/assets", serv)
        .route("/", get(root))
        .route("/home", get(root))
        .route("/login",post(rest::login::login))
        .route("/logout",post(rest::login::logout))
        .route("/me",get(rest::login::me))
        .nest("/api", api_routes)
        .with_state(Arc::new(Mutex::new(database::AppState{db:database::Database::new(pool)})))
        .layer(session_layer);
    
    axum::Server::bind(&"0.0.0.0:3000".parse().unwrap())
    .serve(app.into_make_service())
    .await?;
    anyhow::Ok(())

}



async fn root(State(state): State<Arc<Mutex<database::AppState>>>) -> impl IntoResponse {
    let content = std::fs::read_to_string("./frontend/dist/index.html")
    .unwrap_or_else(|_| "Error: Failed to read file".to_string());
    Response::builder()
        .header("content-type", "text/html")
        .body(content)
        .unwrap()
}

async fn create_user(
    Json(payload): Json<CreateUser>,
) -> (StatusCode, Json<User>) {
    let user = User {
        id: 1337,
        username: payload.username,
    };

    (StatusCode::CREATED, Json(user))
}



#[derive(Deserialize)]
struct CreateUser {
    username: String,
}

#[derive(Serialize)]
struct User {
    id: u64,
    username: String,
}