use serde::{Deserialize,Serialize};
use sqlx::{FromRow,postgres::PgRow,Row};
use anyhow::Result;
use sea_query::{Query, PostgresQueryBuilder,Expr, query};
use crate::database::tables::{Roles,Users};

#[derive(Debug,Serialize,Deserialize,Clone,FromRow)]
pub struct Role {
    pub id: i32,
    pub name: String,
    pub access_files:i32,
    pub access_users:i32,
    pub access_tenders:i32,
    pub access_keys:i32,
}

#[derive(Debug,Serialize,Deserialize,Clone,FromRow)]
pub struct User {
    pub id: i32,
    pub role_id:i32,
    pub name: String,
    pub username: String,
    #[serde(skip_serializing)]
    pub password:String,
}

impl crate::database::Database{
    pub async fn get_roles(& self)->Result<Vec<Role>>{
        let query=Query::select().from(Roles::Table)
        .columns([Roles::Name,Roles::AccessFiles,Roles::Id,Roles::AccessKeys,Roles::AccessTenders,Roles::AccessUsers])
        .to_string(PostgresQueryBuilder);
        let v=sqlx::query(&query).fetch_all(&self.db).await.unwrap_or(vec![]);
        Ok(v.into_iter().map(|row|{Role::from_row(&row).unwrap()}).collect())
    }
    pub async fn add_user(& self,user: User)->Result<i32>{
        let query=Query::insert().into_table(Users::Table)
        .returning_col(Users::Id)
        .columns([Users::Name,Users::RoleId,Users::Username,Users::Password])
        .values([user.name.into(),user.role_id.into(),user.username.into(),user.password.into()])
        .unwrap()
        .to_string(PostgresQueryBuilder);
        let res=sqlx::query(&query).fetch_one(&self.db).await?;
        Ok(res.get(0))
    }
    pub async fn edit_user(& self,idv:&i32, user: User) -> Result<()> {
        let query=Query::update().table(Users::Table)
        .values([(Users::Name,user.name.into()),(Users::Password,user.password.into()),
        (Users::RoleId,user.role_id.into()),(Users::Username,user.username.into())])
        .and_where(Expr::col(Users::Id).eq(*idv))
        .to_string(PostgresQueryBuilder);
        sqlx::query(&query).execute(&self.db).await?;
        Ok(())
    }
    pub async fn delete_user(&  self,idv:&i32)->Result<()>{
        let query=Query::delete().from_table(Users::Table)
        .and_where(Expr::col(Users::Id).eq(*idv))
        .to_string(PostgresQueryBuilder);
        sqlx::query(&query).execute(&self.db).await?;
        Ok(())
    }
    pub async fn get_user(& self,idv:&i32)->Result<User>{
        let query=Query::select().from(Users::Table)
        .and_where(Expr::col(Users::Id).eq(*idv))
        .columns([Users::Id,Users::Name,Users::Password,Users::RoleId,Users::Username])
        .to_string(PostgresQueryBuilder);

        let row=sqlx::query(&query).fetch_one(&self.db).await?;
        Ok(User::from_row(&row)?)
    }
    pub async fn get_users(& self)->Result<Vec<User>>{
        let query=Query::select().from(Users::Table)
        .columns([Users::Id,Users::Name,Users::Password,Users::RoleId,Users::Username])
        .to_string(PostgresQueryBuilder);

        let res=sqlx::query(&query).fetch_all(&self.db).await.unwrap_or(vec![]);
        Ok(res.into_iter().map(|row|{User::from_row(&row).unwrap()}).collect())
    }
    pub async fn get_auth(& mut self, username:String,password:String)->Result<i32>{
        let query=Query::select().from(Users::Table)
        .column(Users::Id)
        .and_where(Expr::col(Users::Username).eq(username))
        .and_where(Expr::col(Users::Password).eq(password))
        .to_string(PostgresQueryBuilder);
        
        let res=sqlx::query(&query).fetch_one(&self.db).await?;
        Ok(res.get(0))
    }
}