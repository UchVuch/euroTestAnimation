mod tables;
mod tenders;
pub mod files;
pub mod users;

use sea_query::OnConflict;
use sea_query::Query;
use sqlx::Row;
use anyhow::Result;
pub use tenders::Tender;

#[derive(serde::Serialize,serde::Deserialize)]
pub struct DataTableResponse<T> where T : serde::Serialize{
    pub data:T,
    pub records_total:u64,
    pub records_filtered:u64,
}
#[derive(serde::Serialize,serde::Deserialize)]
pub struct IdResponse {
    pub id:i64,
}

pub struct AppState{
    pub db:Database,
}
pub struct Database{
    db:sqlx::Pool<sqlx::Postgres>,
}
impl Database{
    pub fn new(db:sqlx::Pool<sqlx::Postgres>)->Self{
        Self { db }
    }
    pub async fn save_table_settings(&self,settings:serde_json::Value,user_id:i64)->Result<()>{
        let a=sqlx::query("insert into tenders_table_settings (user_id,settings) values (1,$1) ON CONFLICT (user_id) DO UPDATE 
        SET settings = $1").bind(&settings).execute(&self.db).await;
        Ok(())
    }
    pub async fn get_table_settings(&self,user_id:i64)->Result<serde_json::Value>{
        let a=sqlx::query("select settings from tenders_table_settings where user_id=1").fetch_one(&self.db).await;
        
        a.map(|row|{
                row.get(0)
        }).map_err(|err|{
            anyhow::anyhow!(err.to_string())
        })
    }
}