create table roles(
      id SERIAL PRIMARY KEY,
      name varchar not null,
      is_admin boolean not null
);
CREATE TABLE users (
       id SERIAL PRIMARY KEY,
       role_id integer not null,
       name varchar not null,
       username varchar not null unique,
       password varchar not null,
       foreign key (role_id) references roles (id)
);
insert into roles (name,is_admin) values ('Администратор',true);
insert into roles (name,is_admin) values ('Пользователь',false);
insert into users (role_id,name,username,password) values (1,'Администратор','admin','admin');