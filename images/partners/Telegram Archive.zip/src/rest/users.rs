use std::sync::Arc;
use crate::database::users::{User,Role};
use serde::{Serialize,Deserialize};
use axum::{
    extract::State,
    extract::Query,
    Json,
    response::{IntoResponse},
};
use axum_sessions::{
    extractors::{ReadableSession},
};
use axum::extract::Path;
use tokio::sync::Mutex;

use crate::{database::AppState, rest::result_to_response};


pub async fn rolesList(data: State<Arc<Mutex<AppState>>>)->impl IntoResponse{
    let mut a=data.lock().await;
    let roles = a.db.get_roles().await;
    result_to_response(roles)
}


pub async fn usersList(data: State<Arc<Mutex<AppState>>>)->impl IntoResponse{
    let mut a=data.lock().await;
    let users = a.db.get_users().await;
    result_to_response(users)
}

pub async fn deleteUser(
    Path(id): Path<i32>,
    data: State<Arc<Mutex<AppState>>>)->impl IntoResponse{
    let mut api=data.lock().await;
    let res=api.db.delete_user(&id).await;
    result_to_response(res)
}

pub async fn editUser(
    data: State<Arc<Mutex<AppState>>>, 
    Path(id): Path<i32>, 
    Json(user): Json<User>) ->impl IntoResponse{
    let mut api=data.lock().await;
    let res=api.db.edit_user(&id,user).await;
    result_to_response(res)
}

pub async fn addUser(data: State<Arc<Mutex<AppState>>>,
    Json(user): Json<User>)->impl IntoResponse{
    let mut api=data.lock().await;
    let res=api.db.add_user(user).await;
    #[derive(Serialize,Deserialize)]
    struct AddUserResponse{
        user_id:i32,
    }
    result_to_response(res.map(|id|AddUserResponse{user_id:id}))
}


pub async fn getUser(
    data: State<Arc<Mutex<AppState>>>,
    Path(id): Path<i32>)->impl IntoResponse{
    let mut api=data.lock().await;
    let res=api.db.get_user(&id).await;
    result_to_response(res)
}
