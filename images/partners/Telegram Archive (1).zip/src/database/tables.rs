
#[derive(sea_query::Iden)]
pub enum Contracts{
    Table,
    Id,
    TenderId,
    SellerName,
    CustomerName,
    ContractAmount,
    ContractDate,
    GuaranteeAmount,
    GuaranteeDate,
    Number,
    Date,
    TermsDate,
    TermsNote,
    Addresses,
    Contacts,
}
#[derive(sea_query::Iden)]
pub enum Files{
    Table,
    Id,
    Path,
    Caption
}

#[derive(sea_query::Iden)]
pub enum Dirs{
    Table,
    Id,
    Path
}

#[derive(sea_query::Iden)]
pub enum Roles{
    Table,
    Id,
    Name,
    AccessFiles,
    AccessKeys,
    AccessTenders,
    AccessUsers,
}
#[derive(sea_query::Iden)]
pub enum Users{
    Table,
    Id,
    RoleId,
    Name,
    Username,
    Password
}

#[derive(sea_query::Iden)]
pub enum Tenders{
    Table,
    Id,
}

#[derive(sea_query::Iden)]
pub enum Shipments{
    Table,
    Id,
    TenderId,
    Date,
}

#[derive(sea_query::Iden)]
pub enum Inspections{
    Table,
    Id,
    TenderId,
    Penalties,
    Payment,
    Approved,
}



#[derive(sea_query::Iden)]
pub enum ContractEquipment{
    Table,
    ContractId,
    Name,
    Count,
    Price,
    Variation,
}
#[derive(sea_query::Iden)]
pub enum ShipmentEquipment{
    Table,
    ShipmentId,
    Name,
    Count,
    Price,
    Variation,
}