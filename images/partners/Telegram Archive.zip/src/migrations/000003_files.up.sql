CREATE TABLE files (
       id SERIAL PRIMARY KEY,
       path VARCHAR NOT NULL unique,
       caption varchar not null
);
create table dirs(
       id SERIAL PRIMARY KEY,
       path VARCHAR NOT NULL unique
);