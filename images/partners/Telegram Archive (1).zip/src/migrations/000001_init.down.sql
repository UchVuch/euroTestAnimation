drop table tenders cascade;
drop table contracts cascade;
drop table shipments cascade;
drop table inspections cascade;
drop table shipment_equipment cascade;
drop table contract_equipment cascade;
drop table tenders_table_settings;