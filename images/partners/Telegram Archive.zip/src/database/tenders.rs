use anyhow::Result;
use sea_query::{ReturningClause, PostgresQueryBuilder, Expr, Alias};
use crate::database::{*};

use super::tables::Tenders;

#[derive(serde::Serialize,serde::Deserialize,Clone)]
pub struct EquipmentUnit{
    pub name:String,
    pub count:i32,
    pub price:f64,
    pub variation:String
}

#[derive(serde::Serialize,serde::Deserialize,Clone)]
pub struct Terms{
    pub date:i64,
    pub note:String,
}
#[derive(serde::Serialize,serde::Deserialize,Clone)]
pub struct Procuring{
    pub guarantee:ProcuringUnit,
    pub contract:ProcuringUnit,
}

#[derive(serde::Serialize,serde::Deserialize,Clone)]
pub struct ProcuringUnit{
    pub amount:f64,
    pub date:i64,
}
#[derive(serde::Serialize,serde::Deserialize,Clone)]
pub struct Contract{
    pub number:i64,
    pub procuring:Procuring,
    pub terms:Terms,
    pub addresses:Vec<String>,
    pub contacts:Vec<String>,
    pub date:Option<i64>,
    pub customer_name:String,
    pub seller_name:String,
    pub equipment:Vec<EquipmentUnit>,
}
#[derive(serde::Serialize,serde::Deserialize,Clone)]
pub struct Shipment{
    pub date:i64,
    pub equipment:Vec<EquipmentUnit>,
}
#[derive(serde::Serialize,serde::Deserialize,Clone,sqlx::FromRow)]
pub struct Inspection{
    pub penalties:f64,
    pub payment:f64,
    pub approved:bool,
}
#[derive(serde::Serialize,serde::Deserialize,Clone)]
pub struct Tender{
    pub id:i32,
    pub contract:Contract,
    pub shipment:Option<Shipment>,
    pub inspection:Option<Inspection>,
}

struct TenderQueries{}
impl TenderQueries{
    fn upsert_contract(tender_id:&i32,c:&Contract)->String{
        use crate::database::tables::Contracts;
        sea_query::Query::insert().into_table(Contracts::Table)
        .returning_col(Contracts::Id)
        .columns([Contracts::TenderId,Contracts::SellerName,Contracts::CustomerName,
            Contracts::ContractAmount,Contracts::ContractDate,Contracts::GuaranteeAmount,
            Contracts::GuaranteeDate,Contracts::Number,Contracts::Date,Contracts::TermsDate,
            Contracts::TermsNote,Contracts::Addresses,Contracts::Contacts
            ])
        .on_conflict(
            OnConflict::column(Contracts::TenderId)
            .update_columns([Contracts::SellerName,Contracts::CustomerName,
                Contracts::ContractAmount,Contracts::ContractDate,Contracts::GuaranteeAmount,
                Contracts::GuaranteeDate,Contracts::Number,Contracts::Date,Contracts::TermsDate,
                Contracts::TermsNote,Contracts::Addresses,Contracts::Contacts])
            .to_owned(),
        )
        .values([(*tender_id).into(),c.seller_name.clone().into(),c.customer_name.clone().into(),
        c.procuring.contract.amount.into(),c.procuring.contract.date.into(),c.procuring.guarantee.amount.into(),
        c.procuring.guarantee.date.into(),c.number.into(),c.date.into(),c.terms.date.into(),
        c.terms.note.clone().into(),
        format!("{{{}}}",c.addresses.join(",")).into(),
        format!("{{{}}}",c.contacts.join(",")).into()])
        
        .expect("213").to_string(sea_query::PostgresQueryBuilder)
    }
    fn upsert_shipment(tender_id:&i32,s:&Shipment)->String{
        use crate::database::tables::Shipments;
        sea_query::Query::insert().into_table(Shipments::Table)
        .returning_col(Shipments::Id)
        .columns([Shipments::TenderId,Shipments::Date])
        .on_conflict(OnConflict::column(Shipments::TenderId).update_columns([Shipments::Date]).to_owned())
        .values([(*tender_id).into(),s.date.into()]).expect("1234").to_string(sea_query::PostgresQueryBuilder)
    }
    fn upsert_inspection(tender_id:&i32,i:&Inspection)->String{
        use crate::database::tables::Inspections;
        sea_query::Query::insert().into_table(Inspections::Table)
        .columns([Inspections::TenderId,Inspections::Payment,Inspections::Penalties,Inspections::Approved])
        .on_conflict(OnConflict::column(Inspections::TenderId).update_columns([Inspections::Payment,Inspections::Penalties,Inspections::Approved]).to_owned())
        .values([(*tender_id).into(),i.payment.into(),i.penalties.into(),i.approved.into()]).expect("1234").to_string(sea_query::PostgresQueryBuilder)
    }
    fn upsert_equipment_contract(contract_id:&i32,s:&EquipmentUnit)->String{
        use crate::database::tables::ContractEquipment;
        sea_query::Query::insert().into_table(ContractEquipment::Table)
        .columns([ContractEquipment::ContractId,ContractEquipment::Count,ContractEquipment::Name,ContractEquipment::Price,ContractEquipment::Variation])
        .values([(*contract_id).into(),s.count.into(),s.name.clone().into(),s.price.into(),s.variation.clone().into()]).expect("1234").to_string(sea_query::PostgresQueryBuilder)
    }
    fn upsert_equipment_shipment(shipment_id:&i32,s:&EquipmentUnit)->String{
    use crate::database::tables::ShipmentEquipment;
    sea_query::Query::insert().into_table(ShipmentEquipment::Table)
    .columns([ShipmentEquipment::ShipmentId,ShipmentEquipment::Count,ShipmentEquipment::Name,ShipmentEquipment::Price,ShipmentEquipment::Variation])
    .values([(*shipment_id).into(),s.count.into(),s.name.clone().into(),s.price.into(),s.variation.clone().into()]).expect("1234").to_string(sea_query::PostgresQueryBuilder)
}
    fn delete_all_equipment_contract(contract_id:&i32)->String{
        use crate::database::tables::ContractEquipment;
        Query::delete().from_table(ContractEquipment::Table).and_where(Expr::col(ContractEquipment::ContractId).eq(contract_id.clone())).to_string(PostgresQueryBuilder)
    }
    fn delete_all_equipment_shipment(shipment_id:&i32)->String{
        use crate::database::tables::ShipmentEquipment;
        Query::delete().from_table(ShipmentEquipment::Table).and_where(Expr::col(ShipmentEquipment::ShipmentId).eq(shipment_id.clone())).to_string(PostgresQueryBuilder)
    }
}




impl crate::database::Database{
    async fn _get_equipment<R,T>(&self,table_name:R,id_col_name:T,id:&i32)->Result<Vec<EquipmentUnit>>
    where R:sea_query::IntoTableRef,T:sea_query::IntoColumnRef{
        use crate::database::tables::{ContractEquipment,ShipmentEquipment};
        
        let query=Query::select().from(table_name)
        .columns([ContractEquipment::Count,ContractEquipment::Name,ContractEquipment::Price,
            ContractEquipment::Variation])
        .and_where(Expr::col(id_col_name).eq(id.clone()))
        .to_string(PostgresQueryBuilder);
        tracing::info!("{}",query);
        let res=sqlx::query(&query).fetch_all(&self.db).await?;
        Ok(res.iter().map(|row|{
            EquipmentUnit{
                count: row.get(0),
                name: row.get(1),
                price: row.get(2),
                variation: row.get(3),
            }
        }).collect())
    }
    async fn _get_contract(&self,id:i32)->Result<Contract>{
        use crate::database::tables::{Contracts,ContractEquipment};
        
        let query=Query::select().from(Contracts::Table)
        .columns([Contracts::Addresses,Contracts::Contacts,Contracts::ContractAmount,Contracts::ContractDate,
            Contracts::GuaranteeAmount,Contracts::GuaranteeDate,Contracts::TermsDate,Contracts::TermsNote,
            Contracts::CustomerName,Contracts::Date,
            Contracts::Number,Contracts::SellerName])
        .and_where(Expr::col(Contracts::Id).eq(id))
        .to_string(PostgresQueryBuilder);

        let equipment=self._get_equipment(ContractEquipment::Table, ContractEquipment::ContractId,&id).await?;

        let result=sqlx::query(&query).fetch_one(&self.db).await?;
        
        
        Ok(Contract { 
            addresses: result.get(0), 
            contacts: result.get(1), 
            procuring: Procuring { 
                contract: ProcuringUnit { amount: result.get(2), date: result.get(3) },
                guarantee: ProcuringUnit { amount: result.get(4), date: result.get(5) }, 
            }, 
            terms: Terms { 
                date: result.get(6), 
                note: result.get(7), 
            }, 
            customer_name: result.get(8), 
            date: result.get(9), 
            number: result.get(10),
            seller_name: result.get(11), 
            equipment, 
        })
    }
    async fn _get_shipment(&self,id:i32)->Result<Shipment>{
        use crate::database::tables::Shipments;
        use crate::database::tables::ShipmentEquipment;
        let query=Query::select().from(Shipments::Table)
        .columns([Shipments::Date])
        .and_where(Expr::col(Shipments::Id).eq(id))
        .to_string(PostgresQueryBuilder);
        let date:i64=sqlx::query(&query).fetch_one(&self.db).await?.get(0);
        let equipment=self._get_equipment(ShipmentEquipment::Table, ShipmentEquipment::ShipmentId,&id).await.unwrap();
        
        Ok(Shipment{date,equipment})
    }
    async fn _get_inspection(&self,id:i32)->Result<Inspection>{
        use crate::database::tables::Inspections;
        let query=Query::select().from(Inspections::Table)
        .columns([Inspections::Approved,Inspections::Payment,Inspections::Penalties])
        .and_where(Expr::col(Inspections::Id).eq(id))
        .to_string(PostgresQueryBuilder);

        sqlx::query_as::<_,Inspection>(&query).fetch_one(&self.db).await
        .map_err(|err|{
            anyhow::anyhow!("{}",err.to_string())
        })
    }
    pub async fn add_tender(&self,tender:Tender)->Result<IdResponse>{
        let query=Query::insert().into_table(Tenders::Table).returning_col(Tenders::Id).or_default_values().to_string(PostgresQueryBuilder);
        let idres:i32=sqlx::query(&query)
        .fetch_one(&self.db).await?.get(0);

        let query=TenderQueries::upsert_contract(&idres, &tender.contract);
        let contract_id=sqlx::query(&query).fetch_one(&self.db).await?.get(0);

        for e in tender.contract.equipment{
            let query=TenderQueries::upsert_equipment_contract(&contract_id, &e);
            sqlx::query(&query).execute(&self.db).await?;
        }

        if let Some(shipment)=tender.shipment{  
            let query=TenderQueries::upsert_shipment(&idres, &shipment);
            let shipment_id=sqlx::query(&query).fetch_one(&self.db).await?.get(0);
            for e in shipment.equipment{
                let query=TenderQueries::upsert_equipment_shipment(&shipment_id,& e);
                sqlx::query(&query).execute(&self.db).await?;
            }
        }
        if let Some(inspection)=tender.inspection{
            let query=TenderQueries::upsert_inspection(&idres,&inspection);
            sqlx::query(&query).execute(&self.db).await?;
        }

        Ok(IdResponse { id: idres.into() })
    }
    pub async fn get_tenders(&self,offset:u64,count:u64)->Result<DataTableResponse<Vec<Tender>>>{
        use crate::database::tables::Contracts;
        let query=Query::select().from(Tenders::Table)
        .column(Tenders::Id)
        .offset(offset)
        .limit(count)
        .to_string(PostgresQueryBuilder);
        
        let rows=sqlx::query(&query).fetch_all(&self.db).await?;
        let mut tenders=vec![];
        for i in rows{
                let tender_id:i32=i.get("id");
                match self.get_tender(tender_id.clone()).await{
                    Ok(t)=>{
                        tenders.push(t);
                    },
                    Err(err)=>{       
                        tracing::error!("{:?}",err);
                    }
                }
        }
        let count_query=format!("select count(*) from tenders");
        let count:i64=sqlx::query(&count_query).fetch_one(&self.db).await.unwrap().get(0);

        Ok(DataTableResponse{
            records_total:count as u64,
            records_filtered:count as u64,
            data:tenders,
        })
    }
    pub async fn get_tender(&self,id:i32)->Result<Tender>{
        use crate::database::tables::Contracts;
        use crate::database::tables::Shipments;
        use crate::database::tables::Inspections;
    
        let query=Query::select().from(Contracts::Table)
        .and_where(Expr::col(Contracts::TenderId).eq(id))
        .column(Contracts::Id)
        .to_string(PostgresQueryBuilder);
        let contract_row=sqlx::query(&query).fetch_one(&self.db).await?;
        let contract=self._get_contract(contract_row.get(0)).await?;

        let query=Query::select().from(Shipments::Table)
        .and_where(Expr::col(Shipments::TenderId).eq(id))
        .column(Shipments::Id)
        .to_string(PostgresQueryBuilder);
        let shipment_row=sqlx::query(&query).fetch_one(&self.db).await;
        let shipment=
            if let Ok(shipment_row)=shipment_row{
                self._get_shipment(shipment_row.get(0)).await.ok()
            }else{
                None
            };

        let query=Query::select().from(Inspections::Table)
        .and_where(Expr::col(Inspections::TenderId).eq(id))
        .column(Inspections::Id)
        .to_string(PostgresQueryBuilder);
        let inspection_row=sqlx::query(&query).fetch_one(&self.db).await;
        let inspection=
            if let Ok(inspection_row)=inspection_row{
                self._get_inspection(inspection_row.get(0)).await.ok()
            }else{
                None
            };

        Ok(Tender { id, contract, shipment, inspection })
    }
    pub async fn update_tender(&self,id:i32,tender:Tender)->Result<()>{
        use crate::database::tables::{Contracts,ContractEquipment,ShipmentEquipment,Shipments,Inspections};
        let contract_id:i32=sqlx::query(TenderQueries::upsert_contract(&id, &tender.contract).as_str()).fetch_one(&self.db).await?.get(0);
        sqlx::query(&&TenderQueries::delete_all_equipment_contract(&contract_id).as_str()).execute(&self.db).await?;
        for e in tender.contract.equipment{
            let query=TenderQueries::upsert_equipment_contract(&contract_id, &e);
                sqlx::query(&query).execute(&self.db).await?;
        }
        if let Some(shipment)=tender.shipment{
            let shipment_id:i32=sqlx::query(TenderQueries::upsert_shipment(&id, &shipment).as_str()).fetch_one(&self.db).await?.get(0);
            sqlx::query(&TenderQueries::delete_all_equipment_shipment(&shipment_id).as_str()).execute(&self.db).await?;
            for e in shipment.equipment{
                let query=TenderQueries::upsert_equipment_shipment(&shipment_id, &e);
                sqlx::query(&query).execute(&self.db).await?;
            }
        }
        if let Some(inspection)=tender.inspection{
            sqlx::query(&TenderQueries::upsert_inspection(&id, &inspection).as_str()).execute(&self.db).await;
        }
        Ok(())
    }
    pub async fn delete_tender(&self,id:i64)->Result<()>{
        todo!()
    }
}
