use axum::{
    extract::State,
    extract::Query,
    Json,
    response::{IntoResponse},
};
use axum_sessions::{
    extractors::{ReadableSession},
};
use axum::extract::Path;
use http::HeaderMap;
use crate::database::{AppState,Tender};
use std::sync::Arc;
use tokio::sync::Mutex;
use crate::rest::result_to_response;



pub async fn get_tenders(
    Query(page): Query<crate::rest::Pagination>,
    State(state): State<Arc<Mutex<AppState>>>,
)->impl IntoResponse{
    let db=&state.lock().await.db;
    let tenders=db.get_tenders(page.start,page.length).await;
    result_to_response(tenders)
}

pub async fn get_tender(
    Path(id): Path<i32>,
    State(state): State<Arc<Mutex<AppState>>>,
)->impl IntoResponse{
    let db=&state.lock().await.db;
    let res = db.get_tender(id).await;
    result_to_response(res)
}

pub async fn add_tender(
    State(state): State<Arc<Mutex<AppState>>>,
    Json(tender): Json<Tender>,
)->impl IntoResponse{
    let db=&state.lock().await.db;
    let res=db.add_tender(tender).await;
    result_to_response(res)
}

pub async fn update_tender(
    Path(id): Path<i32>,
    State(state): State<Arc<Mutex<AppState>>>,
    Json(tender): Json<Tender>,
)->impl IntoResponse{
    let db=&state.lock().await.db;
    let res=db.update_tender(id,tender).await;
    result_to_response(res)
}

pub async fn delete_tender(
    Path(id): Path<i64>,
    State(state): State<Arc<Mutex<AppState>>>,
)->impl IntoResponse{
    let db=& state.lock().await.db;
    let res=db.delete_tender(id).await;
    result_to_response(res)
}

pub async fn save_table_settings(
    headers: HeaderMap,
    State(state): State<Arc<Mutex<AppState>>>,
    Json(payload): Json<serde_json::Value>
)->impl IntoResponse{
    let user_id:i64=headers.get("user_id").unwrap().to_str().unwrap().parse().unwrap();
    let db=& state.lock().await.db;
    let res=db.save_table_settings(payload,user_id).await;
    result_to_response(res)
}

pub async fn get_table_settings(
    headers: HeaderMap,
    State(state): State<Arc<Mutex<AppState>>>,
)->impl IntoResponse{
    let db=& state.lock().await.db;
    let user_id:i64=headers.get("user_id").unwrap().to_str().unwrap().parse().unwrap();
    let res=db.get_table_settings(user_id).await;
    result_to_response(res)
}