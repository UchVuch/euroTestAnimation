create table tenders(
    id serial primary key not null
);
CREATE TABLE contracts (
    id SERIAL PRIMARY KEY,
    tender_id integer not null references tenders(id) on delete cascade unique,
    seller_name TEXT not null,
    customer_name TEXT not null,
    contract_amount float8 not null,
    contract_date bigint not null,
    guarantee_amount float8 not null,
    guarantee_date bigint not null,
    number bigint not null,
    date bigint not null,
    terms_date bigint,
    terms_note TEXT not null,
    addresses TEXT[] not null,
    contacts TEXT[] not null
);

CREATE TABLE shipments (
    id SERIAL PRIMARY KEY,
    tender_id integer not null references tenders(id) on delete cascade unique,
    date bigint not null
);

CREATE TABLE inspections (
    id SERIAL PRIMARY KEY,
    tender_id integer not null references tenders(id) on delete cascade unique,
    penalties float8 not null,
    payment float8 not null,
    approved BOOLEAN not null
);

create table tenders_table_settings(
    user_id serial primary key not null,
    settings jsonb not null
);  

create table shipment_equipment(
    shipment_id integer not null references shipments(id) on delete cascade,
    name text not null,
    count integer not null,
    price float8 not null,
    variation text not null
);
create table contract_equipment(
    contract_id integer not null references contracts(id) on delete cascade,
    name text not null,
    count integer not null,
    price float8 not null,
    variation text not null
);