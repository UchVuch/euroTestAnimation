pub mod login;
pub mod tenders;
pub mod files;
pub mod users;
pub mod keys;

use axum::{
    routing::{get, post},
    extract::State,
    Json, Router,
    http::{Request, StatusCode},
    response::{IntoResponse, Response},
};

#[derive(serde::Deserialize)]
pub struct Pagination{
    pub start:u64,
    pub length:u64,
}
pub fn result_to_response<T>(object:anyhow::Result<T>)->impl IntoResponse where T:serde::Serialize{
    match object{
        Ok(object) => (StatusCode::OK,Json(object)).into_response(),
        Err(err) => (StatusCode::INTERNAL_SERVER_ERROR,err.to_string()).into_response(),
    }
}